```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
```


```python
churn_df=pd.read_csv(r"C:\Users\impri\OneDrive\ドキュメント\python_churn_data.csv")
internet_df = pd.read_csv(r"C:\Users\impri\OneDrive\ドキュメント\Python_internet_data_2.csv")
customer_df = pd.read_csv(r"C:\Users\impri\OneDrive\ドキュメント\Python_customer_data.csv")


```


```python
print(churn_df.head())
print(internet_df.head())
print(customer_df.head())

```

       customerID  tenure PhoneService        Contract PaperlessBilling  \
    0  7590-VHVEG       1           No  Month-to-month              Yes   
    1  5575-GNVDE      34          Yes        One year               No   
    2  3668-QPYBK       2          Yes  Month-to-month              Yes   
    3  7795-CFOCW      45           No        One year               No   
    4  9237-HQITU       2          Yes  Month-to-month              Yes   
    
                   PaymentMethod  MonthlyCharges  TotalCharges Churn  \
    0           Electronic check           29.85         29.85    No   
    1               Mailed check           56.95       1889.50    No   
    2               Mailed check           53.85        108.15   Yes   
    3  Bank transfer (automatic)           42.30       1840.75    No   
    4           Electronic check           70.70        151.65   Yes   
    
       Tenure In Month  
    0            29.85  
    1          1936.30  
    2           107.70  
    3          1903.50  
    4           141.40  
       customerID     MultipleLines InternetService OnlineSecurity OnlineBackup  \
    0  7590-VHVEG  No phone service             DSL             No          Yes   
    1  5575-GNVDE                No             DSL            Yes           No   
    2  3668-QPYBK                No             DSL            Yes          Yes   
    3  7795-CFOCW  No phone service             DSL            Yes           No   
    4  9237-HQITU                No     Fiber optic             No           No   
    
      DeviceProtection TechSupport StreamingTV StreamingMovies  
    0               No          No          No              No  
    1              Yes          No          No              No  
    2               No          No          No              No  
    3              Yes         Yes          No              No  
    4               No          No          No              No  
       customerID  gender  SeniorCitizen Partner Dependents  Day  year  month  \
    0  7590-VHVEG  Female              0     Yes         No   29  1998      1   
    1  5575-GNVDE    Male              0      No         No   12  1983      9   
    2  3668-QPYBK    Male              0      No         No   15  1996      5   
    3  7795-CFOCW    Male              0      No         No   19  2001      2   
    4  9237-HQITU  Female              0      No         No   23  1980     12   
    
       day2  Age  
    0    29   27  
    1    12   41  
    2    15   28  
    3    19   24  
    4    23   44  
    


```python
merged_df = pd.merge(churn_df, customer_df, on='customerID', how='inner')
merged_df = pd.merge(merged_df, internet_df, on='customerID', how='inner')

```


```python
print(merged_df.head())
```

       customerID  tenure PhoneService        Contract PaperlessBilling  \
    0  7590-VHVEG       1           No  Month-to-month              Yes   
    1  5575-GNVDE      34          Yes        One year               No   
    2  3668-QPYBK       2          Yes  Month-to-month              Yes   
    3  7795-CFOCW      45           No        One year               No   
    4  9237-HQITU       2          Yes  Month-to-month              Yes   
    
                   PaymentMethod  MonthlyCharges  TotalCharges Churn  \
    0           Electronic check           29.85         29.85    No   
    1               Mailed check           56.95       1889.50    No   
    2               Mailed check           53.85        108.15   Yes   
    3  Bank transfer (automatic)           42.30       1840.75    No   
    4           Electronic check           70.70        151.65   Yes   
    
       Tenure In Month  ... day2  Age     MultipleLines InternetService  \
    0            29.85  ...   29   27  No phone service             DSL   
    1          1936.30  ...   12   41                No             DSL   
    2           107.70  ...   15   28                No             DSL   
    3          1903.50  ...   19   24  No phone service             DSL   
    4           141.40  ...   23   44                No     Fiber optic   
    
       OnlineSecurity  OnlineBackup  DeviceProtection  TechSupport  StreamingTV  \
    0              No           Yes                No           No           No   
    1             Yes            No               Yes           No           No   
    2             Yes           Yes                No           No           No   
    3             Yes            No               Yes          Yes           No   
    4              No            No                No           No           No   
    
      StreamingMovies  
    0              No  
    1              No  
    2              No  
    3              No  
    4              No  
    
    [5 rows x 27 columns]
    


```python
print(merged_df.isnull().sum())
```

    customerID           0
    tenure               0
    PhoneService         0
    Contract             0
    PaperlessBilling     0
    PaymentMethod        0
    MonthlyCharges       0
    TotalCharges        11
    Churn                0
    Tenure In Month      0
    gender               0
    SeniorCitizen        0
    Partner              0
    Dependents           0
    Day                  0
    year                 0
    month                0
    day2                 0
    Age                  0
    MultipleLines        0
    InternetService      0
    OnlineSecurity       0
    OnlineBackup         0
    DeviceProtection     0
    TechSupport          0
    StreamingTV          0
    StreamingMovies      0
    dtype: int64
    


```python
for col in ['TotalCharges']:
    print(f"{col}: {merged_df[col].unique()}")
```

    TotalCharges: [  29.85 1889.5   108.15 ...  346.45  306.6  6844.5 ]
    


```python
print(merged_df.head())
```

       customerID  tenure PhoneService        Contract PaperlessBilling  \
    0  7590-VHVEG       1           No  Month-to-month              Yes   
    1  5575-GNVDE      34          Yes        One year               No   
    2  3668-QPYBK       2          Yes  Month-to-month              Yes   
    3  7795-CFOCW      45           No        One year               No   
    4  9237-HQITU       2          Yes  Month-to-month              Yes   
    
                   PaymentMethod  MonthlyCharges  TotalCharges Churn  \
    0           Electronic check           29.85         29.85    No   
    1               Mailed check           56.95       1889.50    No   
    2               Mailed check           53.85        108.15   Yes   
    3  Bank transfer (automatic)           42.30       1840.75    No   
    4           Electronic check           70.70        151.65   Yes   
    
       Tenure In Month  ... day2  Age     MultipleLines InternetService  \
    0            29.85  ...   29   27  No phone service             DSL   
    1          1936.30  ...   12   41                No             DSL   
    2           107.70  ...   15   28                No             DSL   
    3          1903.50  ...   19   24  No phone service             DSL   
    4           141.40  ...   23   44                No     Fiber optic   
    
       OnlineSecurity  OnlineBackup  DeviceProtection  TechSupport  StreamingTV  \
    0              No           Yes                No           No           No   
    1             Yes            No               Yes           No           No   
    2             Yes           Yes                No           No           No   
    3             Yes            No               Yes          Yes           No   
    4              No            No                No           No           No   
    
      StreamingMovies  
    0              No  
    1              No  
    2              No  
    3              No  
    4              No  
    
    [5 rows x 27 columns]
    

**Univariate Analysis**

**Numerical Data**


```python
numerical_columns = ['tenure','Age', 'MonthlyCharges', 'TotalCharges']
for column in numerical_columns:
    plt.figure(figsize=(8, 5))
    sns.histplot(merged_df[column], bins=30, kde=True, color='red')
    plt.title(f'Distribution of {column}')
    plt.xlabel(column)
    plt.ylabel('Frequency')
    plt.show()
```


    
![png](output_10_0.png)
    



    
![png](output_10_1.png)
    



    
![png](output_10_2.png)
    



    
![png](output_10_3.png)
    



```python
plt.figure(figsize=(8, 5))
sns.boxplot(x=merged_df['MonthlyCharges'] ,color="cyan")
plt.title('Boxplot of Monthly Charges')
plt.show()
```


    
![png](output_11_0.png)
    



```python
plt.figure(figsize=(6, 4))
sns.countplot(x=merged_df['Churn'],color="mediumblue")
plt.title('Churn Count')
plt.show()
```


    
![png](output_12_0.png)
    



```python
plt.figure(figsize=(8,5))
sns.countplot(x=merged_df['InternetService'])
plt.title('Count of Internet Service Types')
plt.xlabel('Internet Service')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.show()
```


    
![png](output_13_0.png)
    



```python
plt.figure(figsize=(6,6))
merged_df['Churn'].value_counts().plot.pie(autopct='%1.1f%%', colors=['cyan', 'lightblue'])
plt.title('Churn Percentage')
plt.ylabel('')
plt.show()
```


    
![png](output_14_0.png)
    



```python
plt.figure(figsize=(8,5))
sns.kdeplot(merged_df['TotalCharges'], fill=True, color='yellow')
plt.title('KDE Plot of Total Charges')
plt.xlabel('Total Charges')
plt.ylabel('Density')
plt.show()
```


    
![png](output_15_0.png)
    


**Bivariate Analysis**


```python
plt.figure(figsize=(8, 5))
sns.countplot(x=merged_df["Contract"], hue=merged_df["Churn"], palette="coolwarm_r")
plt.title("Churn Rate by Contract Type")
plt.show()
```


    
![png](output_17_0.png)
    



```python
plt.figure(figsize=(8, 5))
sns.boxplot(x=df_selected["Churn"], y=df_selected["MonthlyCharges"])
plt.title("Monthly Charges Distribution by Churn")
plt.show()
```


    
![png](output_18_0.png)
    



```python
plt.figure(figsize=(8, 5))
sns.scatterplot(x=merged_df["tenure"], y=merged_df["TotalCharges"], hue=merged_df["Churn"], alpha=0.7, palette="coolwarm_r")
sns.set_style("whitegrid")
plt.title("Tenure vs. Total Charges")
plt.show()
```


    
![png](output_19_0.png)
    



```python
plt.figure(figsize=(7,5))
sns.scatterplot(x="TotalCharges", y="MonthlyCharges", hue="Churn", data=merged_df , palette="coolwarm_r")
plt.title("Total Charges vs Monthly Charges")
plt.show()
```


    
![png](output_20_0.png)
    


**Multivariate**


```python
print(merged_df.dtypes)
```

    customerID           object
    tenure                int64
    PhoneService         object
    Contract             object
    PaperlessBilling     object
    PaymentMethod        object
    MonthlyCharges      float64
    TotalCharges        float64
    Churn                object
    Tenure In Month     float64
    gender               object
    SeniorCitizen         int64
    Partner              object
    Dependents           object
    Day                   int64
    year                  int64
    month                 int64
    day2                  int64
    Age                   int64
    MultipleLines        object
    InternetService      object
    OnlineSecurity       object
    OnlineBackup         object
    DeviceProtection     object
    TechSupport          object
    StreamingTV          object
    StreamingMovies      object
    dtype: object
    


```python
merged_df["customerID"] = pd.to_numeric(merged_df["customerID"], errors='coerce')
```


```python
numeric_df = merged_df.select_dtypes(include=['int64', 'float64'])
plt.figure(figsize=(12, 8))
sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap")
plt.show()
```


    
![png](output_24_0.png)
    



```python
sns.pairplot(merged_df, hue="Churn")
plt.show()
```


    
![png](output_25_0.png)
    



```python
selected_columns = ["TotalCharges", "MonthlyCharges", "tenure", "Churn"]
df_selected = merged_df[selected_columns]
sns.pairplot(df_selected, hue="Churn", diag_kind="kde", corner=True)
plt.show()
```


    
![png](output_26_0.png)
    



```python

```
